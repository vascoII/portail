<?php

namespace App\Service;

use App\Model\CustomerCase;
use App\Model\CustomerCaseRequest;
use App\Service\Client;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class CustomerNotificationService
{
  private $client;
  private $logger;
  private $session;

  public function __construct(Client $client, LoggerInterface $logger, SessionInterface $session)
  {
    $this->client = $client;
    $this->logger = $logger;
    $this->session = $session;
  }

  /**
   * Valide une requête de cas client
   */
  public function validateCaseRequest(CustomerCaseRequest $request): array
  {
    $errors = [];

    if (empty($request->getCaseId())) {
      $errors[] = "Le numéro de demande est requis.";
    } elseif (!$this->isValidCaseId($request->getCaseId())) {
      $errors[] = "Le format du numéro de demande est invalide.";
    }

    if (empty($request->getEmail())) {
      $errors[] = "L'adresse e-mail est requise.";
    } elseif (!$this->isValidEmail($request->getEmail())) {
      $errors[] = "L'adresse e-mail n'est pas valide.";
    }

    return $errors;
  }

  /**
   * Récupère un cas depuis le WebService
   */
  public function getCaseFromWebService(CustomerCaseRequest $request): ?CustomerCase
  {
    try {
      $this->logger->info('Récupération du cas client', [
        'case_id' => $request->getCaseId(),
        'email' => $request->getEmail()
      ]);

      $result = $this->client->getCasePublic($request->getCaseId(), $request->getEmail());

      if (!$result || !isset($result->getCaseResult)) {
        $this->logger->error('Échec de récupération du cas', [
          'case_id' => $request->getCaseId(),
          'email' => $request->getEmail()
        ]);
        return null;
      }

      return $this->processCaseData($result, $request->getEmail());
    } catch (\Exception $e) {
      $this->logger->error('Erreur lors de la récupération du cas', [
        'case_id' => $request->getCaseId(),
        'email' => $request->getEmail(),
        'error' => $e->getMessage()
      ]);
      return null;
    }
  }

  /**
   * Traite les données du cas récupérées du WebService
   */
  private function processCaseData($result, string $email): CustomerCase
  {
    $caseData = $result->getCaseResult;
    $customerCase = new CustomerCase();

    $customerCase->setId($caseData->Id ?? null);
    $customerCase->setCaseNumber($caseData->CaseNumber ?? null);
    $customerCase->setStatus($caseData->Statut ?? null);
    $customerCase->setSubject($caseData->Subject ?? null);
    $customerCase->setType($caseData->Type ?? null);
    $customerCase->setCategory($caseData->Categorie ?? null);
    $customerCase->setSubcategory($caseData->SousCategorie ?? null);
    $customerCase->setError($caseData->Erreur ?? null);
    $customerCase->setEmail($email);

    // Traitement des ordres de travail
    if (isset($caseData->ListeWorkOrderSF->workOrderSF)) {
      $workOrders = is_array($caseData->ListeWorkOrderSF->workOrderSF)
        ? $caseData->ListeWorkOrderSF->workOrderSF
        : [$caseData->ListeWorkOrderSF->workOrderSF];

      $customerCase->setWorkOrders($workOrders);
    }

    return $customerCase;
  }

  /**
   * Valide un ID de cas
   */
  private function isValidCaseId(string $caseId): bool
  {
    return preg_match('/^[a-zA-Z0-9_-]+$/', $caseId) && strlen($caseId) <= 50;
  }

  /**
   * Valide une adresse email
   */
  private function isValidEmail(string $email): bool
  {
    return filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($email) <= 254;
  }

  /**
   * Nettoie un ID de cas
   */
  public function cleanCaseId(string $caseId): ?string
  {
    $cleaned = trim(htmlspecialchars($caseId, ENT_QUOTES, 'UTF-8'));
    return $this->isValidCaseId($cleaned) ? $cleaned : null;
  }

  /**
   * Nettoie une adresse email
   */
  public function cleanEmail(string $email): ?string
  {
    $cleaned = trim(strtolower(htmlspecialchars($email, ENT_QUOTES, 'UTF-8')));
    return $this->isValidEmail($cleaned) ? $cleaned : null;
  }

  /**
   * Génère un token CSRF pour la session
   */
  public function generateCSRFToken(): string
  {
    if (!$this->session->has('csrf_token')) {
      $this->session->set('csrf_token', bin2hex(random_bytes(32)));
    }
    return $this->session->get('csrf_token');
  }

  /**
   * Valide un token CSRF
   */
  public function validateCSRFToken(string $token): bool
  {
    return $this->session->has('csrf_token') && hash_equals($this->session->get('csrf_token'), $token);
  }
}
