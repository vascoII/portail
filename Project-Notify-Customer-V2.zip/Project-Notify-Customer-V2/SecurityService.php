<?php

namespace App\Service\Security;

use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\Request;

class SecurityService
{
  private $logger;
  private $rateLimitService;

  public function __construct(LoggerInterface $logger, RateLimitService $rateLimitService)
  {
    $this->logger = $logger;
    $this->rateLimitService = $rateLimitService;
  }

  /**
   * Vérifie les tentatives d'attaque
   */
  public function checkAttackAttempts(Request $request): bool
  {
    if (!$this->validateHttpHeaders($request)) {
      $this->logSecurityEvent('INVALID_HEADERS', [
        'ip' => $request->getClientIp(),
        'user_agent' => $request->headers->get('User-Agent')
      ]);
      return false;
    }

    $attackPatterns = [
      'sql' => ['union', 'select', 'insert', 'update', 'delete', 'drop', 'create'],
      'xss' => ['<script', 'javascript:', 'onload', 'onerror', 'onclick'],
      'lfi' => ['../', '..\\', 'php://', 'file://'],
      'rfi' => ['http://', 'https://', 'ftp://', 'data://']
    ];

    foreach ($request->request->all() as $key => $value) {
      if (is_string($value)) {
        $value = strtolower($value);
        foreach ($attackPatterns as $type => $patterns) {
          foreach ($patterns as $pattern) {
            if (strpos($value, $pattern) !== false) {
              $this->logSecurityEvent('ATTACK_ATTEMPT', [
                'type' => $type,
                'pattern' => $pattern,
                'value' => $value,
                'ip' => $request->getClientIp(),
                'key' => $key
              ]);
              return false;
            }
          }
        }
      }
    }

    return true;
  }

  /**
   * Valide les headers HTTP
   */
  private function validateHttpHeaders(Request $request): bool
  {
    $userAgent = $request->headers->get('User-Agent');

    // Vérifier que le User-Agent n'est pas vide
    if (empty($userAgent)) {
      return false;
    }

    // Vérifier que le User-Agent n'est pas suspect
    $suspiciousPatterns = [
      'curl',
      'wget',
      'python',
      'bot',
      'crawler',
      'spider'
    ];

    foreach ($suspiciousPatterns as $pattern) {
      if (stripos($userAgent, $pattern) !== false) {
        return false;
      }
    }

    return true;
  }

  /**
   * Valide l'origine de la requête
   */
  public function validateRequestOrigin(Request $request): bool
  {
    $referer = $request->headers->get('Referer');
    $host = $request->getHost();

    // Si pas de referer, c'est probablement un accès direct (OK pour notre cas)
    if (empty($referer)) {
      return true;
    }

    // Vérifier que le referer vient du même domaine
    $refererHost = parse_url($referer, PHP_URL_HOST);
    return $refererHost === $host;
  }

  /**
   * Nettoie les données d'entrée
   */
  public function sanitizeInput($data)
  {
    if (is_array($data)) {
      return array_map([$this, 'sanitizeInput'], $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
  }

  /**
   * Vérifie le rate limiting
   */
  public function checkRateLimit(string $identifier, string $action = 'default'): bool
  {
    $isAllowed = $this->rateLimitService->isAllowed($identifier, $action);

    if (!$isAllowed) {
      $this->logSecurityEvent('RATE_LIMIT_EXCEEDED', [
        'identifier' => $identifier,
        'action' => $action
      ]);
    }

    return $isAllowed;
  }

  /**
   * Obtient les statistiques de rate limiting
   */
  public function getRateLimitStats(string $identifier, string $action = 'default'): array
  {
    return $this->rateLimitService->getStats($identifier, $action);
  }

  /**
   * Réinitialise le rate limiting
   */
  public function resetRateLimit(string $identifier, string $action = 'default'): bool
  {
    return $this->rateLimitService->reset($identifier, $action);
  }

  /**
   * Envoie les headers de sécurité
   */
  public function sendSecurityHeaders(): void
  {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Content-Security-Policy: default-src \'self\'; script-src \'self\' \'unsafe-inline\' cdn.jsdelivr.net; style-src \'self\' \'unsafe-inline\' cdn.jsdelivr.net; img-src \'self\' data:; font-src \'self\' cdn.jsdelivr.net;');
  }

  /**
   * Log un événement de sécurité
   */
  public function logSecurityEvent(string $event, array $data = []): void
  {
    $logData = array_merge([
      'timestamp' => date('Y-m-d\TH:i:s'),
      'event' => $event,
      'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
      'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
      'request_uri' => $_SERVER['REQUEST_URI'] ?? 'unknown'
    ], $data);

    $this->logger->info('Security event', $logData);
  }
}
