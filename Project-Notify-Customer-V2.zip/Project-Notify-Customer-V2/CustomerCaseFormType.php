<?php

namespace App\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;

class CustomerCaseFormType extends AbstractType
{
  public function buildForm(FormBuilderInterface $builder, array $options)
  {
    $builder
      ->add('caseId', HiddenType::class, [
        'required' => true,
        'constraints' => [
          new NotBlank(['message' => 'Le numéro de demande est requis.'])
        ]
      ])
      ->add('email', EmailType::class, [
        'required' => true,
        'label' => 'Adresse e-mail',
        'attr' => [
          'placeholder' => 'exemple@email.com',
          'class' => 'form-control',
          'autocomplete' => 'email'
        ],
        'constraints' => [
          new NotBlank(['message' => 'L\'adresse e-mail est requise.']),
          new Email(['message' => 'Veuillez saisir une adresse e-mail valide.'])
        ]
      ])
      ->add('submit', SubmitType::class, [
        'label' => 'Accéder à ma demande',
        'attr' => [
          'class' => 'btn btn-primary'
        ]
      ]);
  }

  public function configureOptions(OptionsResolver $resolver)
  {
    $resolver->setDefaults([
      'data_class' => 'App\Model\CustomerCaseRequest',
      'attr' => [
        'id' => 'customer-case-form',
        'novalidate' => true
      ]
    ]);
  }

  public function getBlockPrefix()
  {
    return 'customer_case';
  }
}
