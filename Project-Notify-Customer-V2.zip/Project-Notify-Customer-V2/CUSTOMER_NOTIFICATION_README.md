# Feature Customer Notification

## Description

Cette feature permet aux clients de consulter leurs demandes d'intervention sans authentification, en utilisant uniquement leur adresse e-mail et le numéro de demande.

## Fonctionnalités

### ✅ Implémentées

- **Formulaire de saisie** : Interface pour saisir l'email et le case_id
- **Page de chargement** : Animation de chargement avec progression
- **Détails de cas** : Affichage des informations de la demande
- **Détails d'ordre de travail** : Vue détaillée des ordres de travail
- **Téléchargement de rapports** : PDF des interventions
- **Sécurité** : Rate limiting, validation CSRF, détection d'attaques
- **Logging** : Traçabilité complète des actions
- **Responsive** : Interface adaptée mobile/desktop

### 🚫 Exclues (gardées standalone)

- Pages d'administration (`/admin/*`)
- Gestion des logs de sécurité
- Gestion du rate limiting admin
- Tests de rate limiting

## Architecture

### Contrôleurs

- `CustomerNotificationController` : Contrôleur principal de la feature

### Services

- `CustomerNotificationService` : Logique métier principale
- `SecurityService` : Gestion de la sécurité
- `RateLimitService` : Rate limiting

### Modèles

- `CustomerCase` : Modèle pour les cas clients
- `CustomerCaseRequest` : Modèle pour les requêtes

### Formulaires

- `CustomerCaseFormType` : Formulaire de saisie
- `CustomerCaseVerifyFormType` : Formulaire de vérification

### Templates

- `email_case_form.html.twig` : Formulaire initial
- `email_case_verify.html.twig` : Page de chargement
- `case_details.html.twig` : Détails du cas
- `work_order_details.html.twig` : Détails ordre de travail

## Routes

```yaml
customer_case_form: /customer-case
customer_case_verify: /customer-case/verify
customer_case_details: /customer-case/details
customer_work_order_details: /customer-case/work-order
customer_download_report: /customer-case/download-report
```

## Configuration

### Sécurité

Les routes sont configurées comme `PUBLIC_ACCESS` dans `security.yaml`.

### Services

Les services sont configurés dans `services.yaml` avec injection de dépendances.

### Rate Limiting

- **Form access** : 10 tentatives/heure
- **Form submit** : 5 soumissions/heure
- **Case details** : 20 accès/heure
- **Work order details** : 15 accès/heure
- **Download report** : 10 téléchargements/heure

## Utilisation

### Accès direct

```
/customer-case?caseid=5003X00002tdGOCQA2
```

### Flux utilisateur

1. **Saisie** : L'utilisateur saisit son email
2. **Vérification** : Page de chargement avec animation
3. **Détails** : Affichage des informations du cas
4. **Ordres de travail** : Consultation des détails
5. **Rapports** : Téléchargement des PDF

## Sécurité

### Protection CSRF

- Token CSRF généré pour chaque session
- Validation systématique des formulaires

### Rate Limiting

- Limitation par IP + case_id
- Stockage en cache avec expiration
- Logging des tentatives excessives

### Détection d'attaques

- Validation des headers HTTP
- Détection de patterns malveillants (SQLi, XSS, LFI, RFI)
- Vérification de l'origine des requêtes

### Logging

- Événements de sécurité
- Appels WebService
- Erreurs et exceptions

## WebService

### Méthodes ajoutées au Client

- `getCasePublic($caseId, $email)` : Récupération d'un cas public
- `getReportPublic($workOrderNumber)` : Téléchargement de rapport public

### Authentification

Utilise les identifiants super admin pour les appels publics.

## Assets

### CSS

- `public/css/customer-notification.css` : Styles spécifiques
- Intégration dans `base.html.twig`

### JavaScript

- `public/js/customer-notification.js` : Interactions client
- Validation côté client
- Animations de chargement
- Gestion des erreurs

## Traductions

- `translations/customer_notification.fr.yaml` : Traductions françaises
- Support multilingue prêt

## Tests

### Données de test

```
Email : gthernisien@techem.fr ou fnginamau@1001vieshabitat.fr
Case ID : 5003X00002tdGOCQA2 ou 500SZ00000iJEApYAO
```

### URLs de test

```
http://localhost/customer-case?caseid=5003X00002tdGOCQA2
```

## Maintenance

### Logs

Les logs sont stockés dans :

- Sécurité : `var/log/security.log`
- WebService : `var/log/webservice.log`

### Cache

Le rate limiting utilise le cache Symfony avec TTL configurable.

### Monitoring

Surveiller les métriques de rate limiting et les tentatives d'attaque.

## Évolutions futures

### Fonctionnalités à implémenter

- [ ] Retour en arrière natif (stockage session)
- [ ] Notifications par email
- [ ] Historique des consultations
- [ ] Export des données
- [ ] API REST

### Améliorations

- [ ] Tests unitaires
- [ ] Tests d'intégration
- [ ] Documentation API
- [ ] Métriques avancées
- [ ] Interface d'administration

## Support

Pour toute question ou problème :

1. Vérifier les logs dans `var/log/`
2. Contrôler la configuration dans `config/packages/customer_notification.yaml`
3. Tester avec les données de test fournies
4. Consulter la documentation Symfony pour les services
