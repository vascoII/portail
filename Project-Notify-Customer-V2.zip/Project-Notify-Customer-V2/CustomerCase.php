<?php

namespace App\Model;

class CustomerCase
{
  private $id;
  private $caseNumber;
  private $status;
  private $subject;
  private $type;
  private $category;
  private $subcategory;
  private $error;
  private $workOrders = [];
  private $email;

  public function __construct()
  {
    $this->workOrders = [];
  }

  public function getId(): ?string
  {
    return $this->id;
  }

  public function setId(?string $id): self
  {
    $this->id = $id;
    return $this;
  }

  public function getCaseNumber(): ?string
  {
    return $this->caseNumber;
  }

  public function setCaseNumber(?string $caseNumber): self
  {
    $this->caseNumber = $caseNumber;
    return $this;
  }

  public function getStatus(): ?string
  {
    return $this->status;
  }

  public function setStatus(?string $status): self
  {
    $this->status = $status;
    return $this;
  }

  public function getSubject(): ?string
  {
    return $this->subject;
  }

  public function setSubject(?string $subject): self
  {
    $this->subject = $subject;
    return $this;
  }

  public function getType(): ?string
  {
    return $this->type;
  }

  public function setType(?string $type): self
  {
    $this->type = $type;
    return $this;
  }

  public function getCategory(): ?string
  {
    return $this->category;
  }

  public function setCategory(?string $category): self
  {
    $this->category = $category;
    return $this;
  }

  public function getSubcategory(): ?string
  {
    return $this->subcategory;
  }

  public function setSubcategory(?string $subcategory): self
  {
    $this->subcategory = $subcategory;
    return $this;
  }

  public function getError(): ?string
  {
    return $this->error;
  }

  public function setError(?string $error): self
  {
    $this->error = $error;
    return $this;
  }

  public function getWorkOrders(): array
  {
    return $this->workOrders;
  }

  public function setWorkOrders(array $workOrders): self
  {
    $this->workOrders = $workOrders;
    return $this;
  }

  public function addWorkOrder($workOrder): self
  {
    $this->workOrders[] = $workOrder;
    return $this;
  }

  public function getEmail(): ?string
  {
    return $this->email;
  }

  public function setEmail(?string $email): self
  {
    $this->email = $email;
    return $this;
  }

  public function hasError(): bool
  {
    return !empty($this->error);
  }

  public function getWorkOrdersCount(): int
  {
    return count($this->workOrders);
  }
}
