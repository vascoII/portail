<?php

namespace App\Controller;

use App\Form\CustomerCaseFormType;
use App\Form\CustomerCaseVerifyFormType;
use App\Model\CustomerCaseRequest;
use App\Service\CustomerNotificationService;
use App\Service\Security\SecurityService;
use Psr\Log\LoggerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

class CustomerNotificationController extends AbstractController
{
  private $customerNotificationService;
  private $securityService;
  private $logger;

  public function __construct(
    CustomerNotificationService $customerNotificationService,
    SecurityService $securityService,
    LoggerInterface $logger
  ) {
    $this->customerNotificationService = $customerNotificationService;
    $this->securityService = $securityService;
    $this->logger = $logger;
  }

  /**
   * Formulaire de saisie email + case_id
   */
  #[Route('/customer-case', name: 'customer_case_form', methods: ['GET', 'POST'])]
  public function emailCaseFormAction(Request $request): Response
  {
    // Vérifier les tentatives d'attaque
    if (!$this->securityService->checkAttackAttempts($request)) {
      $this->securityService->logSecurityEvent('ATTACK_BLOCKED');
      return new Response('Accès refusé pour des raisons de sécurité.', 403);
    }

    // Vérifier l'origine de la requête
    if (!$this->securityService->validateRequestOrigin($request)) {
      return new Response('Origine de la requête invalide.', 400);
    }

    $caseId = $request->query->get('caseid', '');
    $caseRequest = new CustomerCaseRequest();
    $caseRequest->setCaseId($caseId);

    $form = $this->createForm(CustomerCaseFormType::class, $caseRequest);

    if ($request->isMethod('POST')) {
      $form->handleRequest($request);

      if ($form->isSubmitted() && $form->isValid()) {
        $data = $form->getData();

        // Vérifier le rate limiting
        $identifier = $request->getClientIp() . '_' . $data->getCaseId();
        if (!$this->securityService->checkRateLimit($identifier, 'form_access')) {
          $this->addFlash('error', 'Trop de tentatives d\'accès. Veuillez réessayer dans 15 minutes.');
          return $this->redirectToRoute('customer_case_form', ['caseid' => $data->getCaseId()]);
        }

        // Valider les données
        $errors = $this->customerNotificationService->validateCaseRequest($data);
        if (!empty($errors)) {
          foreach ($errors as $error) {
            $this->addFlash('error', $error);
          }
          return $this->redirectToRoute('customer_case_form', ['caseid' => $data->getCaseId()]);
        }

        // Rediriger vers la page de vérification
        return $this->redirectToRoute('customer_case_verify', [
          'caseid' => $data->getCaseId(),
          'email' => $data->getEmail()
        ]);
      }
    }

    return $this->render('CustomerNotification/email_case_form.html.twig', [
      'form' => $form->createView(),
      'case_id' => $caseId
    ]);
  }

  /**
   * Page de chargement et vérification
   */
  #[Route('/customer-case/verify', name: 'customer_case_verify', methods: ['GET', 'POST'])]
  public function emailCaseVerifyAction(Request $request): Response
  {
    // Vérifier les tentatives d'attaque
    if (!$this->securityService->checkAttackAttempts($request)) {
      $this->securityService->logSecurityEvent('ATTACK_BLOCKED');
      return new Response('Accès refusé pour des raisons de sécurité.', 403);
    }

    $caseId = $request->query->get('caseid', '');
    $email = $request->query->get('email', '');

    if (empty($caseId) || empty($email)) {
      $this->addFlash('error', 'Paramètres manquants.');
      return $this->redirectToRoute('customer_case_form');
    }

    $caseRequest = new CustomerCaseRequest();
    $caseRequest->setCaseId($caseId);
    $caseRequest->setEmail($email);

    $form = $this->createForm(CustomerCaseVerifyFormType::class, $caseRequest);

    return $this->render('CustomerNotification/email_case_verify.html.twig', [
      'form' => $form->createView(),
      'case_id' => $caseId,
      'email' => $email
    ]);
  }

  /**
   * Détails du cas client
   */
  #[Route('/customer-case/details', name: 'customer_case_details', methods: ['POST'])]
  public function caseDetailsAction(Request $request): Response
  {
    // Vérifier les tentatives d'attaque
    if (!$this->securityService->checkAttackAttempts($request)) {
      $this->securityService->logSecurityEvent('ATTACK_BLOCKED');
      return new Response('Accès refusé pour des raisons de sécurité.', 403);
    }

    $caseRequest = new CustomerCaseRequest();
    $caseRequest->setCaseId($request->request->get('caseId', ''));
    $caseRequest->setEmail($request->request->get('email', ''));

    // Vérifier le rate limiting
    $identifier = $request->getClientIp() . '_' . $caseRequest->getCaseId();
    if (!$this->securityService->checkRateLimit($identifier, 'case_details')) {
      $this->addFlash('error', 'Trop de tentatives d\'accès aux détails. Veuillez réessayer dans 15 minutes.');
      return $this->redirectToRoute('customer_case_form', ['caseid' => $caseRequest->getCaseId()]);
    }

    // Valider les données
    $errors = $this->customerNotificationService->validateCaseRequest($caseRequest);
    if (!empty($errors)) {
      foreach ($errors as $error) {
        $this->addFlash('error', $error);
      }
      return $this->redirectToRoute('customer_case_form', ['caseid' => $caseRequest->getCaseId()]);
    }

    // Récupérer le cas depuis le WebService
    $customerCase = $this->customerNotificationService->getCaseFromWebService($caseRequest);

    if (!$customerCase) {
      $this->addFlash('error', 'Une erreur est survenue lors de la récupération des données. Veuillez réessayer.');
      return $this->redirectToRoute('customer_case_form', ['caseid' => $caseRequest->getCaseId()]);
    }

    if ($customerCase->hasError()) {
      $this->addFlash('error', 'Une erreur est survenue lors de la récupération des données. Veuillez réessayer.');
      return $this->redirectToRoute('customer_case_form', ['caseid' => $caseRequest->getCaseId()]);
    }

    return $this->render('CustomerNotification/case_details.html.twig', [
      'customerCase' => $customerCase
    ]);
  }

  /**
   * Détails d'un ordre de travail
   */
  #[Route('/customer-case/work-order', name: 'customer_work_order_details', methods: ['POST'])]
  public function workOrderDetailsAction(Request $request): Response
  {
    // Vérifier les tentatives d'attaque
    if (!$this->securityService->checkAttackAttempts($request)) {
      $this->securityService->logSecurityEvent('ATTACK_BLOCKED');
      return new Response('Accès refusé pour des raisons de sécurité.', 403);
    }

    $caseRequest = new CustomerCaseRequest();
    $caseRequest->setCaseId($request->request->get('caseId', ''));
    $caseRequest->setEmail($request->request->get('email', ''));
    $caseRequest->setWorkOrderNumber($request->request->get('workOrderNumber', ''));
    $caseRequest->setWorkOrderPayload($request->request->get('workOrderPayload', ''));

    // Vérifier le rate limiting
    $identifier = $request->getClientIp() . '_' . $caseRequest->getCaseId();
    if (!$this->securityService->checkRateLimit($identifier, 'work_order_details')) {
      $this->addFlash('error', 'Trop de tentatives d\'accès. Veuillez réessayer dans 15 minutes.');
      return $this->redirectToRoute('customer_case_form', ['caseid' => $caseRequest->getCaseId()]);
    }

    if (!$caseRequest->hasWorkOrder()) {
      $this->addFlash('error', 'Paramètres d\'ordre de travail manquants.');
      return $this->redirectToRoute('customer_case_form', ['caseid' => $caseRequest->getCaseId()]);
    }

    // Décoder le payload de l'ordre de travail
    $workOrderData = json_decode(base64_decode($caseRequest->getWorkOrderPayload()), true);

    return $this->render('CustomerNotification/work_order_details.html.twig', [
      'workOrder' => $workOrderData,
      'caseId' => $caseRequest->getCaseId(),
      'email' => $caseRequest->getEmail()
    ]);
  }

  /**
   * Téléchargement de rapport PDF
   */
  #[Route('/customer-case/download-report', name: 'customer_download_report', methods: ['POST'])]
  public function downloadReportAction(Request $request): Response
  {
    // Vérifier les tentatives d'attaque
    if (!$this->securityService->checkAttackAttempts($request)) {
      $this->securityService->logSecurityEvent('ATTACK_BLOCKED');
      return new Response('Accès refusé pour des raisons de sécurité.', 403);
    }

    $workOrderNumber = $request->request->get('workOrderNumber', '');
    $caseId = $request->request->get('caseId', '');

    if (empty($workOrderNumber)) {
      $this->addFlash('error', 'Numéro d\'ordre de travail manquant.');
      return $this->redirectToRoute('customer_case_form', ['caseid' => $caseId]);
    }

    // Vérifier le rate limiting
    $identifier = $request->getClientIp() . '_' . $caseId;
    if (!$this->securityService->checkRateLimit($identifier, 'download_report')) {
      $this->addFlash('error', 'Trop de tentatives de téléchargement. Veuillez réessayer dans 15 minutes.');
      return $this->redirectToRoute('customer_case_form', ['caseid' => $caseId]);
    }

    try {
      // Récupérer le rapport depuis le WebService
      $client = $this->container->get('App\Service\Client');
      $report = $client->getReportPublic($workOrderNumber);

      if (empty($report)) {
        $this->addFlash('error', 'Rapport non trouvé.');
        return $this->redirectToRoute('customer_case_form', ['caseid' => $caseId]);
      }

      $response = new Response($report);
      $response->headers->set('Content-Type', 'application/pdf');
      $response->headers->set('Content-Disposition', 'inline; filename=rapport-intervention-' . $workOrderNumber . '.pdf');
      $response->headers->set('Content-Transfer-Encoding', 'binary');
      $response->headers->set('Expires', 0);
      $response->headers->set('Cache-Control', 'no-cache');
      $response->headers->set('Pragma', 'no-cache');
      $response->headers->set('Content-Length', strlen($report));

      return $response;
    } catch (\Exception $e) {
      $this->logger->error('Erreur lors du téléchargement du rapport', [
        'work_order_number' => $workOrderNumber,
        'case_id' => $caseId,
        'error' => $e->getMessage()
      ]);

      $this->addFlash('error', 'Erreur lors du téléchargement du rapport.');
      return $this->redirectToRoute('customer_case_form', ['caseid' => $caseId]);
    }
  }
}
