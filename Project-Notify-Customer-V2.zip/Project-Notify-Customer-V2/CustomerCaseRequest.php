<?php

namespace App\Model;

class CustomerCaseRequest
{
  private $caseId;
  private $email;
  private $workOrderNumber;
  private $workOrderPayload;

  public function getCaseId(): ?string
  {
    return $this->caseId;
  }

  public function setCaseId(?string $caseId): self
  {
    $this->caseId = $caseId;
    return $this;
  }

  public function getEmail(): ?string
  {
    return $this->email;
  }

  public function setEmail(?string $email): self
  {
    $this->email = $email;
    return $this;
  }

  public function getWorkOrderNumber(): ?string
  {
    return $this->workOrderNumber;
  }

  public function setWorkOrderNumber(?string $workOrderNumber): self
  {
    $this->workOrderNumber = $workOrderNumber;
    return $this;
  }

  public function getWorkOrderPayload(): ?string
  {
    return $this->workOrderPayload;
  }

  public function setWorkOrderPayload(?string $workOrderPayload): self
  {
    $this->workOrderPayload = $workOrderPayload;
    return $this;
  }

  public function isValid(): bool
  {
    return !empty($this->caseId) && !empty($this->email);
  }

  public function hasWorkOrder(): bool
  {
    return !empty($this->workOrderNumber) && !empty($this->workOrderPayload);
  }
}
