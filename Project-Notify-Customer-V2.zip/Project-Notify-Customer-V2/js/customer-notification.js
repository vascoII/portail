/**
 * Customer Notification JavaScript
 * Gestion des interactions pour la feature de notification client
 */

document.addEventListener("DOMContentLoaded", function () {
  // Initialisation des composants
  initFormValidation();
  initLoadingAnimations();
  initTooltips();
  initAlerts();
});

/**
 * Initialise la validation des formulaires
 */
function initFormValidation() {
  const forms = document.querySelectorAll("form[novalidate]");

  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      if (!validateForm(this)) {
        e.preventDefault();
        return false;
      }
    });
  });
}

/**
 * Valide un formulaire
 */
function validateForm(form) {
  let isValid = true;
  const requiredFields = form.querySelectorAll("[required]");

  requiredFields.forEach((field) => {
    if (!field.value.trim()) {
      showFieldError(field, "Ce champ est requis.");
      isValid = false;
    } else if (field.type === "email" && !isValidEmail(field.value)) {
      showFieldError(field, "Veuillez saisir une adresse e-mail valide.");
      isValid = false;
    } else {
      clearFieldError(field);
    }
  });

  return isValid;
}

/**
 * Valide une adresse email
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Affiche une erreur pour un champ
 */
function showFieldError(field, message) {
  clearFieldError(field);

  const errorDiv = document.createElement("div");
  errorDiv.className = "invalid-feedback d-block";
  errorDiv.textContent = message;

  field.classList.add("is-invalid");
  field.parentNode.appendChild(errorDiv);
}

/**
 * Efface l'erreur d'un champ
 */
function clearFieldError(field) {
  field.classList.remove("is-invalid");
  const errorDiv = field.parentNode.querySelector(".invalid-feedback");
  if (errorDiv) {
    errorDiv.remove();
  }
}

/**
 * Initialise les animations de chargement
 */
function initLoadingAnimations() {
  const loadingContainer = document.querySelector(".loading-container");
  if (!loadingContainer) return;

  const progressBar = document.getElementById("progressModern");
  const progressText = document.getElementById("progressText");
  const steps = document.querySelectorAll('[id^="step"]');
  const hiddenForm = document.getElementById("hiddenForm");

  if (!progressBar || !progressText || !hiddenForm) return;

  let progress = 0;
  const interval = setInterval(() => {
    progress += Math.random() * 15;
    if (progress > 100) progress = 100;

    progressBar.style.width = progress + "%";
    progressText.textContent = Math.round(progress) + "%";

    // Mise à jour des étapes
    updateSteps(progress, steps);

    if (progress >= 100) {
      clearInterval(interval);
      setTimeout(() => {
        hiddenForm.submit();
      }, 500);
    }
  }, 200);
}

/**
 * Met à jour l'affichage des étapes
 */
function updateSteps(progress, steps) {
  if (progress >= 30) {
    updateStep(steps[0], "check-circle", "Email vérifié");
  }

  if (progress >= 60) {
    updateStep(steps[1], "check-circle", "Recherche terminée");
  }

  if (progress >= 90) {
    updateStep(steps[2], "check-circle", "Chargement terminé");
  }
}

/**
 * Met à jour une étape
 */
function updateStep(stepElement, iconClass, text) {
  if (!stepElement) return;

  stepElement.classList.remove("step-pending");
  stepElement.classList.add("step-completed");

  const icon = stepElement.querySelector("i");
  if (icon) {
    icon.className = `fas fa-${iconClass} me-2`;
  }

  stepElement.textContent = text;
}

/**
 * Initialise les tooltips
 */
function initTooltips() {
  const tooltipElements = document.querySelectorAll(
    '[data-bs-toggle="tooltip"]'
  );
  if (tooltipElements.length > 0 && typeof bootstrap !== "undefined") {
    tooltipElements.forEach((element) => {
      new bootstrap.Tooltip(element);
    });
  }
}

/**
 * Initialise la gestion des alertes
 */
function initAlerts() {
  const alerts = document.querySelectorAll(".alert");

  alerts.forEach((alert) => {
    const closeBtn = alert.querySelector(".closebtn");
    if (closeBtn) {
      closeBtn.addEventListener("click", function () {
        alert.style.display = "none";
      });
    }
  });
}

/**
 * Affiche une alerte
 */
function showAlert(message, type = "info") {
  const alertContainer =
    document.querySelector(".alert-container") || createAlertContainer();

  const alertDiv = document.createElement("div");
  alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
  alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

  alertContainer.appendChild(alertDiv);

  // Auto-hide après 5 secondes
  setTimeout(() => {
    if (alertDiv.parentNode) {
      alertDiv.remove();
    }
  }, 5000);
}

/**
 * Crée un conteneur d'alertes
 */
function createAlertContainer() {
  const container = document.createElement("div");
  container.className = "alert-container position-fixed top-0 end-0 p-3";
  container.style.zIndex = "1050";
  document.body.appendChild(container);
  return container;
}

/**
 * Gestion des erreurs AJAX
 */
function handleAjaxError(xhr, status, error) {
  console.error("Erreur AJAX:", error);
  showAlert("Une erreur est survenue. Veuillez réessayer.", "danger");
}

/**
 * Affiche un indicateur de chargement
 */
function showLoading(element) {
  const originalContent = element.innerHTML;
  element.dataset.originalContent = originalContent;
  element.innerHTML =
    '<i class="fas fa-spinner fa-spin me-2"></i>Chargement...';
  element.disabled = true;
}

/**
 * Cache l'indicateur de chargement
 */
function hideLoading(element) {
  if (element.dataset.originalContent) {
    element.innerHTML = element.dataset.originalContent;
    delete element.dataset.originalContent;
  }
  element.disabled = false;
}

/**
 * Utilitaires pour la validation des données
 */
const ValidationUtils = {
  /**
   * Valide un ID de cas
   */
  isValidCaseId: function (caseId) {
    return /^[a-zA-Z0-9_-]+$/.test(caseId) && caseId.length <= 50;
  },

  /**
   * Valide une adresse email
   */
  isValidEmail: function (email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
  },

  /**
   * Nettoie une chaîne de caractères
   */
  sanitizeString: function (str) {
    return str.trim().replace(/[<>]/g, "");
  },
};

/**
 * Gestion des événements de sécurité
 */
const SecurityUtils = {
  /**
   * Désactive le copier-coller sur les champs sensibles
   */
  disableCopyPaste: function () {
    const sensitiveFields = document.querySelectorAll(".disableCopyPaste");
    sensitiveFields.forEach((field) => {
      field.addEventListener("copy", (e) => e.preventDefault());
      field.addEventListener("paste", (e) => e.preventDefault());
      field.addEventListener("cut", (e) => e.preventDefault());
    });
  },

  /**
   * Initialise la protection CSRF
   */
  initCSRF: function () {
    const forms = document.querySelectorAll("form");
    forms.forEach((form) => {
      if (!form.querySelector('input[name="csrf_token"]')) {
        const csrfInput = document.createElement("input");
        csrfInput.type = "hidden";
        csrfInput.name = "csrf_token";
        csrfInput.value =
          document.querySelector('meta[name="csrf-token"]')?.content || "";
        form.appendChild(csrfInput);
      }
    });
  },
};

// Initialisation des utilitaires de sécurité
SecurityUtils.disableCopyPaste();
SecurityUtils.initCSRF();
