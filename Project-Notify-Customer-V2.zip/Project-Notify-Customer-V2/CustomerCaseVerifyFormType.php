<?php

namespace App\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class CustomerCaseVerifyFormType extends AbstractType
{
  public function buildForm(FormBuilderInterface $builder, array $options)
  {
    $builder
      ->add('caseId', HiddenType::class, [
        'required' => true,
        'constraints' => [
          new NotBlank(['message' => 'Le numéro de demande est requis.'])
        ]
      ])
      ->add('email', HiddenType::class, [
        'required' => true,
        'constraints' => [
          new NotBlank(['message' => 'L\'adresse e-mail est requise.'])
        ]
      ])
      ->add('workOrderNumber', HiddenType::class, [
        'required' => false
      ])
      ->add('workOrderPayload', HiddenType::class, [
        'required' => false
      ])
      ->add('submit', SubmitType::class, [
        'label' => 'Accéder à ma demande',
        'attr' => [
          'class' => 'btn btn-primary',
          'style' => 'display: none;'
        ]
      ]);
  }

  public function configureOptions(OptionsResolver $resolver)
  {
    $resolver->setDefaults([
      'data_class' => 'App\Model\CustomerCaseRequest',
      'attr' => [
        'id' => 'customer-case-verify-form',
        'style' => 'display: none;'
      ]
    ]);
  }

  public function getBlockPrefix()
  {
    return 'customer_case_verify';
  }
}
