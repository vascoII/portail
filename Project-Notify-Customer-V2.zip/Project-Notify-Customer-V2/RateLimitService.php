<?php

namespace App\Service\Security;

use Psr\Log\LoggerInterface;
use Symfony\Component\Cache\Adapter\FilesystemAdapter;

class RateLimitService
{
  private $cache;
  private $logger;
  private $maxRequests;
  private $timeWindow;

  public function __construct(LoggerInterface $logger, int $maxRequests = 100, int $timeWindow = 3600)
  {
    $this->cache = new FilesystemAdapter('rate_limit', 0, '/tmp/cache');
    $this->logger = $logger;
    $this->maxRequests = $maxRequests;
    $this->timeWindow = $timeWindow;
  }

  /**
   * Vérifie si une action est autorisée selon le rate limiting
   */
  public function isAllowed(string $identifier, string $action = 'default'): bool
  {
    $key = $this->generateKey($identifier, $action);
    $item = $this->cache->getItem($key);

    if (!$item->isHit()) {
      $data = [
        'count' => 1,
        'first_request' => time(),
        'last_request' => time()
      ];
      $item->set($data);
      $item->expiresAfter($this->timeWindow);
      $this->cache->save($item);
      return true;
    }

    $data = $item->get();
    $now = time();

    // Vérifier si la fenêtre de temps est expirée
    if (($now - $data['first_request']) >= $this->timeWindow) {
      $data = [
        'count' => 1,
        'first_request' => $now,
        'last_request' => $now
      ];
      $item->set($data);
      $item->expiresAfter($this->timeWindow);
      $this->cache->save($item);
      return true;
    }

    // Vérifier si le nombre de requêtes est dépassé
    if ($data['count'] >= $this->maxRequests) {
      $this->logger->warning('Rate limit exceeded', [
        'identifier' => $identifier,
        'action' => $action,
        'count' => $data['count'],
        'max_requests' => $this->maxRequests,
        'time_window' => $this->timeWindow
      ]);
      return false;
    }

    // Incrémenter le compteur
    $data['count']++;
    $data['last_request'] = $now;
    $item->set($data);
    $this->cache->save($item);

    return true;
  }

  /**
   * Obtient les statistiques de rate limiting pour un identifiant
   */
  public function getStats(string $identifier, string $action = 'default'): array
  {
    $key = $this->generateKey($identifier, $action);
    $item = $this->cache->getItem($key);

    if (!$item->isHit()) {
      return [
        'count' => 0,
        'remaining' => $this->maxRequests,
        'reset_time' => time() + $this->timeWindow
      ];
    }

    $data = $item->get();
    $now = time();
    $remaining = max(0, $this->maxRequests - $data['count']);
    $resetTime = $data['first_request'] + $this->timeWindow;

    return [
      'count' => $data['count'],
      'remaining' => $remaining,
      'reset_time' => $resetTime,
      'is_blocked' => $remaining === 0 && $now < $resetTime
    ];
  }

  /**
   * Réinitialise le rate limiting pour un identifiant
   */
  public function reset(string $identifier, string $action = 'default'): bool
  {
    $key = $this->generateKey($identifier, $action);
    return $this->cache->deleteItem($key);
  }

  /**
   * Génère une clé de cache pour l'identifiant et l'action
   */
  private function generateKey(string $identifier, string $action): string
  {
    return hash('sha256', $action . '_' . $identifier);
  }

  /**
   * Nettoie les entrées expirées
   */
  public function cleanup(): int
  {
    // Le cache Symfony gère automatiquement l'expiration
    return 0;
  }
}
